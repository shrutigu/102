import os 
import shutil

from_dir = 'K:/'
to_dir = 'Documents/'

list_of_files = os.listdir(from_dir)
print(list_of_files)

for k in list_of_files:
    os.path.splitext()

    